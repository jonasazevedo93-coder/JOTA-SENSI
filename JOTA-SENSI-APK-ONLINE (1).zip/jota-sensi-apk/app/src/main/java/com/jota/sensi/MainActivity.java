package com.jota.sensi;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    requestWindowFeature(Window.FEATURE_NO_TITLE);
    getWindow().setStatusBarColor(android.graphics.Color.rgb(7,9,12));
    getWindow().setNavigationBarColor(android.graphics.Color.rgb(7,9,12));
    WebView w = new WebView(this);
    w.setBackgroundColor(android.graphics.Color.rgb(7,9,12));
    w.setWebViewClient(new WebViewClient());
    WebSettings s = w.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);
    s.setAllowContentAccess(true);
    s.setBuiltInZoomControls(false);
    s.setDisplayZoomControls(false);
    w.loadUrl("file:///android_asset/index.html");
    setContentView(w);
  }
  @Override public void onBackPressed() {
    WebView w = (WebView)findViewById(android.R.id.content).findViewById(android.R.id.content);
    super.onBackPressed();
  }
}
