# JOTA SENSI — gerar APK online

Este projeto está preparado para compilação automática no **GitHub Actions**.
A interface original em `app/src/main/assets/index.html` não é alterada pelo workflow.

## Como gerar

1. Crie um repositório no GitHub e envie **todo o conteúdo desta pasta** para ele.
2. Ao enviar para a branch `main` ou `master`, a compilação começa automaticamente.
3. Abra a aba **Actions**, entre em **Gerar APK - JOTA SENSI** e aguarde terminar.
4. Abra a execução concluída e, em **Artifacts**, baixe `JOTA-SENSI-APK`.

O arquivo gerado é um APK de **debug assinado**, pronto para instalar no Android. Não é necessário Android Studio nem configurar o SDK no computador.

Também é possível iniciar manualmente em **Actions → Gerar APK - JOTA SENSI → Run workflow**.
