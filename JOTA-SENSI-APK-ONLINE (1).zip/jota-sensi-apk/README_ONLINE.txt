JOTA SENSI - PACOTE PREPARADO PARA GERAR APK ONLINE

Este pacote inclui .github/workflows/build-apk.yml.
Ao subir o conteúdo para um repositório GitHub na branch main/master, o GitHub Actions compila automaticamente um APK instalável.

O APK final aparece como artefato com o nome JOTA-SENSI-APK.
A interface HTML original não é modificada.
