JOTA SENSI - APK

Este projeto empacota o HTML original da JOTA SENSI em um app Android WebView, preservando o arquivo HTML sem redesenhar a interface.

Ícone: criado com a identidade visual da própria interface (fundo escuro, grade, laranja e alvo JOTA SENSI).

Para gerar o APK: abra esta pasta em Android Studio e escolha Build > Build APK(s).

Application ID: com.jota.sensi
Versão: 1.0
